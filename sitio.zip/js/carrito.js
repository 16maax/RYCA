let productosEnCarrito = localStorage.getItem("productos-en-carrito")
productosEnCarrito = JSON.parse(productosEnCarrito)

const contenedorCarritoVacio = document.querySelector("#carrito-vacio")
const contenedorCarritoProductos = document.querySelector("#carrito-productos")
const contenedorCarritoAcciones = document.querySelector("#carrito-acciones")
const contenedorCarritoComprado = document.querySelector("#carrito-comprado")
let botonesEliminar = document.querySelectorAll(".carrito-producto-eliminar")
const botonVaciar = document.querySelector("#carrito-acciones-vaciar")
const contenedorTotal = document.querySelector("#total")
const botonComprar = document.querySelector("#carrito-acciones-comprar")

function cargarProductosCarrito(){
    if(productosEnCarrito && productosEnCarrito.length > 0){

        contenedorCarritoVacio.classList.add("disabled")
        contenedorCarritoProductos.classList.remove("disabled")
        contenedorCarritoAcciones.classList.remove("disabled")
        contenedorCarritoComprado.classList.add("disabled")
    
        contenedorCarritoProductos.innerHTML = ""
    
        productosEnCarrito.forEach(producto  => {
            const div = document.createElement("div")
            div.classList.add("carrito-producto")
            div.innerHTML = `
                <img class="carrito-producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
                <div class="carrito-producto-titulo">
                    <small>Titulo</small>
                    <h3>${producto.titulo}</h3>
                </div>
                <div class="carrito-producto-titulo">
                    <small>Articulo</small>
                    <p>${producto.id}</p>
                </div>
                <div class="carrito-producto-cantidad">
                    <small>Cantidad</small>
                    <p>${producto.cantidad}</p>
                </div>
                <div class="carrito-producto-precio">
                    <small>Precio</small>
                    <p>$${producto.precio}</p>
                </div>
                <div class="carrito-producto-subtotal">
                    <small>Subtotal</small>
                    <p>$${producto.precio * producto.cantidad}</p>
                </div>
                <button class="carrito-producto-eliminar" id="${producto.id}"><i class="bi bi-trash3-fill"></i></button>
            `
            contenedorCarritoProductos.append(div)
        })
    }else{
        contenedorCarritoVacio.classList.remove("disabled")
        contenedorCarritoProductos.classList.add("disabled")
        contenedorCarritoAcciones.classList.add("disabled")
        contenedorCarritoComprado.classList.add("disabled")
    }
    actualizarBotonesEliminar()
    actualizarTotal()
}

cargarProductosCarrito()

function actualizarBotonesEliminar(){
    botonesEliminar = document.querySelectorAll(".carrito-producto-eliminar")
    botonesEliminar.forEach(boton => {
        boton.addEventListener("click", eliminarDelCarrito)
    })
}

function eliminarDelCarrito(e) {

    Toastify({
        text: "Producto eliminado",
        duration: 3000,
        close: true,
        gravity: "top", // `top` or `bottom`
        position: "right", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: "linear-gradient(to right, #800080, #ffc0cb)",
          borderRadius: "2rem",
          textTransform: "uppercase",
          fontSize: ".75rem"
        },
        offset: {
            x: '1.5rem', // horizontal axis - can be a number or a string indicating unity. eg: '2em'
            y: '1.5rem' // vertical axis - can be a number or a string indicating unity. eg: '2em'
          },
        onClick: function(){} // Callback after click
      }).showToast();

    const idBoton = e.currentTarget.id
    const index = productosEnCarrito.findIndex(producto => producto.id === idBoton)
    productosEnCarrito.splice(index, 1)
    cargarProductosCarrito()

    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito))
}

botonVaciar.addEventListener("click", vaciarCarrito)
function vaciarCarrito(){

    Swal.fire({
        title: '¿Estas seguro?',
        text: `Se van a borrar ${productosEnCarrito.reduce((acc, producto)=> acc + producto.cantidad, 0)} productos.`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si',
        cancelButtonText: 'No'
      }).then((result) => {
        if (result.isConfirmed) {
            productosEnCarrito.length = 0
            localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito))
            cargarProductosCarrito()
        }
      })
}

function actualizarTotal() {
    const totalCalculado = productosEnCarrito.reduce((acc, producto) => acc + (producto.precio * producto.cantidad), 0)
    total.innerText = `$${totalCalculado}`
}

botonComprar.addEventListener("click", comprarCarrito)
function comprarCarrito(){

    productosEnCarrito.length = 0
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito))
    
    contenedorCarritoVacio.classList.add("disabled")
    contenedorCarritoProductos.classList.add("disabled")
    contenedorCarritoAcciones.classList.add("disabled")        
    contenedorCarritoComprado.classList.remove("disabled")
}


function generarPDF() {
  const fecha = new Date().toLocaleString('es-MX');

  let usuarios = JSON.parse(localStorage.getItem("usuarios"));
  if (usuarios === null) {
    usuarios = [];
    Swal.fire('No hay usuarios registrados')
    return;
  }

  var tableConten = [
    ["Nombre", "CURP", "Tel. Celular", "Correo"],
    ...usuarios.map((usuario) => [usuario.nombre, usuario.curp, usuario.telefono, usuario.correo])
  ];

  // Rest of the code...

  pdfMake.createPdf(docDefinition).download('Cotizacion');
}


/*
function generarPDF2() {

  const fecha = new Date().toLocaleString('es-MX');

  let usuarios = JSON.parse(localStorage.getItem("usuarios"));
  if (usuarios === null) {
    usuarios = [];
  }

  var tableConten = [  ["Nombre", "CURP", "Tel. Celular", "Correo"],
  ...usuarios.map((usuario) => [usuario.nombre, usuario.curp, usuario.telefono, usuario.correo])
];

  const totalCalculado = productosEnCarrito.reduce((acc, producto) => acc + (producto.precio * producto.cantidad), 0);

  var productos = JSON.parse(localStorage.getItem("productos-en-carrito"));

  var tableContent = [
    ["ID", "Categoría", "Título", "Cantidad", "Precio"],
    ...productos.map((producto) => [producto.id, producto.categoria.nombre, producto.titulo, producto.cantidad, "$" + (producto.precio + 1.05)])
  ];
  
  var docDefinition = {
    content: [
      { text: fecha, style: "fecha" },
      { text: "Denominación/Razón Social: REFACCIONAMIENTO Y COMERCIALIZACION PARA LA AUTOMATIZACION", style: "contacto" },
      { text: "Bodega: PROL. AV. PASEOS DE LA ASUNCION #2049, Fracc. Villas de Santa Rosa C.P. 20284", style: "contacto" },
      { text: "Oficina: FRANCISCO G . HORNEDO #231, Zona Centro C.P. 20000", style: "contacto" },
      { text: "Tel. Celular: 4496555878", style: "contacto" }, 
      { text: "WhatsApp: 4491564905", style: "contacto" },
      { text: "RFC: RCA151118120", style: "contacto" },
      { text: "Cotizacion", style: "header", alignment: "center" },
      { text: "Usuario registrado", style: "body" },
      { table: { body: tableConten, style: "body" } },
      { text: "Productos en carrito", style: "body"},
      { table: { body: tableContent, style: "body"} },
      { text: "Total: $" + totalCalculado, style: "body" },
      { text: "Términos comerciales:", alignment: 'center', style: "body" },
      { text: "Precios:", style: "body"},
      { ul: [
        ' Nuestro precio es L.A.B. En ubicación de la obra o en oficinas de nuestro cliente en Aguascalientes, Ags.',
        'Esta cotización incluye solo los Ítems de los equipos mencionados.',
        'Se requiere el 10% de efectivo del total de tu cotizacion para proceder con la compra, si esta es menor a $11,000.00 MNX, en caso de exceder este monto se requerira cubrir el monto excedente en efectivo.',
        'En caso de cancelaciones en compra de equipos, el cliente deberá pagar un 40% del monto total previa autorización.',
      ], style: "terminos" },
      { text: "Es muy importante tener la orden de compra y cubiertas las condiciones de pago para que comience a correr el tiempo de entrega, mismos que dará la Secretaría de Desarrollo Económico, Ciencia y Tecnología del Estado de Aguascalientes.", style: "terminos" }
    ],
    styles: {
      header: {
        fontSize: 15,
        bold: true,
        margin: [0, 0, 0, 10]
      },
      fecha: {
        fontSize: 10,
        bold: true,
        alignment: "right"
      },
      body: {
        fontSize: 12,
        bold: true,
        margin: [0, 8, 0, 8]
      },
      terminos: {
        fontSize: 11,
        bold: false,
        margin: [0, 8, 0, 8]
      },
      contacto: {
        fontSize: 10,
        bold: false,
        margin: [0, 0, 0, 0],
        alignment: "right"
      }
    }
  };

  // Obtener la CURP del primer usuario en la lista
const curp = usuarios[0].curp;

// Crear un elemento HTML "canvas" para dibujar el código de barras
const canvas = document.createElement("canvas");

// Generar el código de barras y dibujarlo en el canvas
JsBarcode(canvas, curp, {
  format: "CODE128",
  displayValue: false,
  height: 30,
  margin: 0,
  textMargin: 0
});

// Obtener la imagen del canvas como una cadena base64
const barcodeImg = canvas.toDataURL();

// Agregar la imagen del código de barras al objeto "docDefinition"
docDefinition.content.unshift({ image: barcodeImg, width: 150, alignment: "center" });

  pdfMake.createPdf(docDefinition).open();
}


function generarPDF3() {

  const fecha = new Date().toLocaleString('es-MX');

  let usuarios = JSON.parse(localStorage.getItem("usuarios"));
  if (usuarios === null) {
    usuarios = [];
  }

  var tableConten = [  ["Nombre", "CURP", "Tel. Celular", "Correo"],
  ...usuarios.map((usuario) => [usuario.nombre, usuario.curp, usuario.telefono, usuario.correo])
];

  const totalCalculado = productosEnCarrito.reduce((acc, producto) => acc + (producto.precio * producto.cantidad), 0);

  var productos = JSON.parse(localStorage.getItem("productos-en-carrito"));

  var tableContent = [
    ["ID", "Categoría", "Título", "Cantidad", "Precio"],
    ...productos.map((producto) => [producto.id, producto.categoria.nombre, producto.titulo, producto.cantidad, "$" + (producto.precio + 1.07)])
  ];
  

  var docDefinition = {
    content: [
      { text: fecha, style: "fecha" },
      { text: "Denominación/Razón Social: REFACCIONAMIENTO Y COMERCIALIZACION PARA LA AUTOMATIZACION", style: "contacto" },
      { text: "Bodega: PROL. AV. PASEOS DE LA ASUNCION #2049, Fracc. Villas de Santa Rosa C.P. 20284", style: "contacto" },
      { text: "Oficina: FRANCISCO G . HORNEDO #231, Zona Centro C.P. 20000", style: "contacto" },
      { text: "Tel. Celular: 4496555878", style: "contacto" }, 
      { text: "WhatsApp: 4491564905", style: "contacto" },
      { text: "RFC: RCA151118120", style: "contacto" },
      { text: "Cotizacion", style: "header", alignment: "center" },
      { text: "Usuario registrado", style: "body" },
      { table: { body: tableConten, style: "body" } },
      { text: "Productos en carrito", style: "body"},
      { table: { body: tableContent, style: "body"} },
      { text: "Total: $" + totalCalculado, style: "body" },
      { text: "Términos comerciales:", alignment: 'center', style: "body" },
      { text: "Precios:", style: "body"},
      { ul: [
        ' Nuestro precio es L.A.B. En ubicación de la obra o en oficinas de nuestro cliente en Aguascalientes, Ags.',
        'Esta cotización incluye solo los Ítems de los equipos mencionados.',
        'Se requiere el 10% de efectivo del total de tu cotizacion para proceder con la compra, si esta es menor a $11,000.00 MNX, en caso de exceder este monto se requerira cubrir el monto excedente en efectivo.',
        'En caso de cancelaciones en compra de equipos, el cliente deberá pagar un 40% del monto total previa autorización.',
      ], style: "terminos" },
      { text: "Es muy importante tener la orden de compra y cubiertas las condiciones de pago para que comience a correr el tiempo de entrega, mismos que dará la Secretaría de Desarrollo Económico, Ciencia y Tecnología del Estado de Aguascalientes.", style: "terminos" }
    ],
    styles: {
      header: {
        fontSize: 15,
        bold: true,
        margin: [0, 0, 0, 10]
      },
      fecha: {
        fontSize: 10,
        bold: true,
        alignment: "right"
      },
      body: {
        fontSize: 12,
        bold: true,
        margin: [0, 8, 0, 8]
      },
      terminos: {
        fontSize: 11,
        bold: false,
        margin: [0, 8, 0, 8]
      },
      contacto: {
        fontSize: 10,
        bold: false,
        margin: [0, 0, 0, 0],
        alignment: "right"
      }
    }
  };

  // Obtener la CURP del primer usuario en la lista
const curp = usuarios[0].curp;

// Crear un elemento HTML "canvas" para dibujar el código de barras
const canvas = document.createElement("canvas");

// Generar el código de barras y dibujarlo en el canvas
JsBarcode(canvas, curp, {
  format: "CODE128",
  displayValue: false,
  height: 30,
  margin: 0,
  textMargin: 0
});

// Obtener la imagen del canvas como una cadena base64
const barcodeImg = canvas.toDataURL();

// Agregar la imagen del código de barras al objeto "docDefinition"
docDefinition.content.unshift({ image: barcodeImg, width: 150, alignment: "center" });

  pdfMake.createPdf(docDefinition).open();
}
*/

function ejecutarFunciones (){
  generarPDF();
  /*generarPDF2();
  generarPDF3();*/
}

